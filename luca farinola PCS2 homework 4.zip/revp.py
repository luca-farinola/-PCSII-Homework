from Bio.Seq import Seq, reverse_complement
with open('revp.txt', 'r') as s:
    seq = Seq("".join(s.read().strip().split("\n")[1:]).strip())

for i in range(len(seq)):
    for j in range(4, 12):
        if i + j < len(seq) and seq[i:i + j] == reverse_complement(seq[i:i + j]):
            print(i + 1, j)

