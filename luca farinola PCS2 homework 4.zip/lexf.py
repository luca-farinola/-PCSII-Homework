from itertools import permutations
with open('lexf.txt','r') as f:
    alpha = f.readline().split()
    n = f.readline()


for comb in list(permutations(alpha,int(n))):
    print('mio:',' '.join(comb))


