from Bio.Seq import reverse_complement
with open('revc.txt', 'r') as s:
    seq = s.readline()

print(reverse_complement(seq))
