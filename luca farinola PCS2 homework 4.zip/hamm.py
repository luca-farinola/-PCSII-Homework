from Bio.Seq import Seq

with open('hamm.txt','r') as s:
    seqa = Seq(s.readline())
    seqb = Seq(s.readline())

c = 0
for x in range(len(seqa)-1):
    if seqa[x] != seqb[x]:
        c+= 1
print(c)