with open('subs.txt', 'r') as s:
    seq = s.readline().strip()
    target = s.readline().strip()

print(seq)
print(target)
l = []
for i in range(len(seq)):
    if target == seq[i:i+len(target)]:
        l.append(str(i+1))

print('soluzione =')
print(' '.join(l))