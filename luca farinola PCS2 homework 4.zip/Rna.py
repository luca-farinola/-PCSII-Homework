from Bio.Seq import transcribe
with open('rna.txt', 'r') as s:
    seq = s.readline()

print(transcribe(seq))
