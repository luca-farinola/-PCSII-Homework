from Bio import SeqIO
l = []

for record in SeqIO.parse("lcsm.fasta", "fasta"):
  l.append(str(record.seq))


def lcs(strs):
    n = min([len(x) for x in strs])
    kmer = set()
    seq = strs[0]
    strs = strs[1:]
    for k in reversed(range(n)):
        for i in range(n + 1 - k):
            kmer.add(seq[i:i + k])
        for kk in kmer:
            found = True
            for x in strs:
                if x.find(kk) == -1:
                    found = False
                    break
            if found == True:
                return (kk)
        kmer = set()

print(lcs(l))
