from Bio import SeqIO
l = []

for record in SeqIO.parse("cons.fasta", "fasta"):
  l.append((record.seq))

import numpy as np
a = np.array(l)
tr = a.transpose()
A = []
C = []
G = []
T = []

for x in tr:
  A.append(str(list(x).count('A')))
  C.append(str(list(x).count('C')))
  G.append(str(list(x).count('G')))
  T.append(str(list(x).count('T')))
L = []
L.append(A)
L.append(C)
L.append(G)
L.append(T)

cons = []
for m in range(0,len(l[0])):
  p = list(np.array(L).transpose()[m])
  if p.index(max(p)) == 0:
    cons.append('A')
  if p.index(max(p)) == 1:
    cons.append('C')
  if p.index(max(p)) == 2:
    cons.append('G')
  if p.index(max(p)) == 3:
    cons.append('T')

print(''.join(cons))
print('A:', ' '.join((L[0])))
print('C:', ' '.join((L[1])))
print('G:', ' '.join((L[2])))
print('T:', ' '.join((L[3])))

