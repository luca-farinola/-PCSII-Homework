import itertools

n = 5
l = []
for x in range(1,n+1):
    l.append(str(x))

print(len(list(itertools.permutations(l))))

for comb in list(itertools.permutations(l,2)):
    print(' '.join(comb))

