def fib(n,k):
 a, b = 1, 1
 for i in range(1, n):
     a, b = b, b + (a*k)
 return a

print(fib(33, 4))
# the dataset given by rosalind was just 33 4