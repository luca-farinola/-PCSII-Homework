from Bio.Seq import Seq
from Bio.SeqUtils import GC
with open('gc.txt','r') as file:
    content = file.read().splitlines()
final, lst = [], []
for i in range(len(content)):
    if content[i][0] == '>':
        final.append(lst)
        lst = [content[i][1:]]
    else:
        lst.append(content[i])
final.append(lst)
final.pop(0)
Final = {}
for i in range(len(final)):
    DNA = ''
    for j in range(1, len(final[i])):
        DNA += final[i][j]
    Final[GC(Seq(DNA))] = final[i][0]
print(Final[max(Final)])
print(max(Final))


