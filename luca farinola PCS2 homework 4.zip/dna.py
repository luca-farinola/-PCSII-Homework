with open('dna.txt', 'r') as s:
    seq = s.readline()
print(seq.count('A'), seq.count('C'), seq.count('G'), seq.count('T'))
