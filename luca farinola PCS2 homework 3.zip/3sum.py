with open('3sum.txt','r') as s:
    siz = s.readline().split(' ')
    r = int(siz[0])
    n = int(siz[1])
    arr = s.read().split('\n') 
    
def threesum(s):
    c = s
    s = sorted(s) 
    new = []
    for k in range(len(s)):
        target = -s[k]
        i,j = k+1,len(s)-1
        while i < j:
            sum_two = s[i] + s[j]
            if sum_two < target:
                i += 1
            elif sum_two > target:
                j -= 1
            else:
                new.append(str(c.index(s[k])+1))
                new.append(str(c.index(s[i])+1))
                new.append(str(c.index(s[j])+1))
                z = ' '.join(sorted(new))
                i += 1
                j -= 1
                return z
    if new == []: 
        return -1
    
    
for x in arr: 
    T = list(map(int,x.split(' '))) 
    print(threesum(T))


    
    
