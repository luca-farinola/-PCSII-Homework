with open('piccolo.txt','r') as s:
    siz = s.readline().split(' ')
    r = int(siz[0])
    n = int(siz[1])
    arr = s.read().split('\n') 
    
    
def two_sum(A):
    new = []
    for p in range(len(A)-1):
        for q in range(p+1, len(A)):
            if A[p] == -A[q] : 
                new.append(str(p+1))
                new.append(str(q+1))
                return ' '.join(new)
    if new == []: return -1
    
for x in arr: 
    T = list(map(int,x.split(' '))) 
    print(two_sum(T))