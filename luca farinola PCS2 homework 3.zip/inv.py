with open('inv.txt','r') as s:
    n = s.readline().split(' ')
    a = s.read().split(' ') 

arrayA = [int(i) for i in a]
sortarrayA = sorted(arrayA)
noInversion = 0
while len(arrayA) > 0:
    b = sortarrayA.index(arrayA[0])
    noInversion += b
    sortarrayA.pop(sortarrayA.index(arrayA[0]))
    arrayA.pop(0)

print (noInversion)
