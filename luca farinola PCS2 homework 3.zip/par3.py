with open('par3.txt','r') as s:
    n = s.readline() 
    arr = s.read().split('\n')

def par3(l) :
 major= []
 minor= []
 equal= []
 for j in range(len(l)):
   if l[j] == l[0]:
    equal.append(str(l[j]))
   if l[j] > l[0]:
    major.append(str(l[j]))
   if l[j] < l[0]:
    minor.append(str(l[j]))
 return minor + equal + major
     
for x in arr: 
    L = list(map(int,x.split(' '))) 
    print(' '.join(par3(L)))
