with open('ms.txt','r') as s:
    n = s.readline()
    a = s.readline().split(' ')

A = ([int(x) for x in a])

st = ''
for x in sorted(A):
    st += ' ' + str(x)
print (st)
