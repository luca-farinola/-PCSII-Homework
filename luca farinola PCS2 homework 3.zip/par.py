with open('par.txt','r') as s:
    n = s.readline() 
    arr = s.read().split('\n')



def par(l) :
 major= []
 minor= []
 for j in range(len(l)):
   if l[j] > l[0]:
    major.append(str(l[j]))
   if l[j] < l[0]:
    minor.append(str(l[j]))
 return minor + [str(l[0])] + major
     
for x in arr: 
    L = list(map(int,x.split(' '))) 
    print(' '.join(par(L)))