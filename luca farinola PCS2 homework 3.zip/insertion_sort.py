with open('ins.txt','r') as s:
    n = s.readline()
    arr = s.readline().split(' ') 
T = ([int(x) for x in arr])

def insertionSort(nlist):
   z = 0 
   for index in range(1,len(nlist)):

     currentvalue = nlist[index]
     position = index

     while position>0 and nlist[position-1]>currentvalue:
         nlist[position]=nlist[position-1]
         position = position-1
         z += 1


     nlist[position]=currentvalue
   print (z)
              
    
insertionSort(T)
