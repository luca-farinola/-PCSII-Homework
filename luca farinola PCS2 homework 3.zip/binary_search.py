with open('bins.txt','r') as s:
    m = s.readline()
    n = s.readline()
    A = (s.readline()).split(' ')
    K = (s.readline()).split(' ')

d = {}
for p in A :
    d[p] = A.index(p)+1
c = []
for x in K : 
    if x in d : 
        c.append(str(d[x]))
    else: 
        c.append(str(-1))
print (' '.join(c))


