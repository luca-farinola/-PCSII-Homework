with open('maj.txt','r') as s:
    lenarr = s.readline().split(' ')
    r = int(lenarr[0])
    c = int(lenarr[1])
    a = s.read().split('\n')
half = c/2

z = []
new =[]

for x in a : 
    z.append(x.split(' '))

        
from collections import Counter

def maj(lst):
    c = Counter(lst)
    val, cnt = c.most_common()[0]
    if cnt > half:
        return str(val)
    else:
        return '-1'

for x in z:
    new.append(maj(x))
print(' '.join(new))
