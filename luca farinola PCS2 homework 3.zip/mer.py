with open('mer.txt','r') as s:
    n = s.readline()
    a = s.readline().split(' ')
    m = s.readline()
    b = s.readline().split(' ')
A = ([int(x) for x in a])
B = ([int(y) for y in b])

st = ''
for x in sorted(A + B):
    st += ' ' + str(x)
print (st)