with open('med.txt','r') as s:
    n = s.readline()
    arr = sorted(list(map(int,s.readline().split(' '))))
    k = int(s.readline())


print(arr[k-1])
