from Bio.Seq import Seq


dna = ''.join(x.strip() for x in open('orf.txt','r').readlines()[1:])
dna1 = str(Seq(dna).reverse_complement())

dnalist = []
for a in range(0,len(dna)):
    if dna[a:a+3] == 'ATG':
        dnalist.append(dna[a:])
    if dna1[a:a+3] == 'ATG':
        dnalist.append(dna1[a:])

aalist = []
for n in dnalist:
    aa = Seq(n).translate()
    if aa.find('*') != -1:
        aalist.append(str(aa[:aa.find('*')]))

print ('\n'.join(y for y in list(set(aalist))))