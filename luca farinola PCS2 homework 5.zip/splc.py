from Bio.Seq import Seq
from Bio import SeqIO

l=[]
for record in SeqIO.parse("splc.fasta", "fasta"):
  l.append(record.seq)


dna_string = l[0]
l.remove(l[0])
introns = l

print(introns)
# We will remove the each intron from the string
for intron in introns:
    dna_string = str(dna_string).replace(str(intron), "")
Spliced = Seq(dna_string).transcribe()

print(Spliced.translate())


