with open("treep.txt", 'r') as f:
 lns = f.read().split()
 nr_edges = int((len(lns) - 1) / 2)
 nodes = int(lns[0])

print(nodes-1 - nr_edges )