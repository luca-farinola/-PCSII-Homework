from Bio.Seq import Seq
from Bio import SeqIO

l=[]
for record in SeqIO.parse("sseq.fasta", "fasta"):
  l.append(record.seq)

q, r = l[1],l[0]

start = 0
indices = []
for i in range(0, len(q)):
    for j in range(start, len(r)):
        if q[i] == r[j] and j not in indices:
            indices.append(j)
            start = j
            break

result = ""
for i in indices:
    result += str(i + 1) + " "

print(result[:-1])

