from Bio import SeqIO
l=[]
for record in SeqIO.parse("tran.fasta", "fasta"):
        l.append((record.seq))

s1 = l[0]
s2 = l[1]
transition = 0
transversion = 0
pur = ['A','G']
pyr = ['C','T']
for i in range(0,len(s1)):
    n1=s1[i]
    n2=s2[i]
    if n1 != n2 :
        if n1 in pur and n2 in pur:
            transition += 1
        if n1 in pyr and n2 in pyr:
            transition += 1
        if n1 in pur and n2 in pyr:
            transversion += 1
        if n1 in pyr and n2 in pur:
            transversion += 1
print(transition/transversion)

