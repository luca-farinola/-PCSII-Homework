names, sequences = [], []
file = open("grph.txt")
for line in file:
    line = line.rstrip()
    if line[0]==">":
        names.append(line[1:])
        sequences.append('')
    else:
        sequences[-1] += line

for (i,s) in enumerate(sequences):
    for j in range(i+1,len(sequences)):
        t = sequences[j]
        if s[-3:] == t[:3]:
            print (names[i], names[j])
        if s[:3] == t[-3:]:
            print (names[j], names[i])